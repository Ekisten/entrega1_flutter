import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart'; // Importamos el paquete para usar fuentes personalizadas de Google
import '../widgets/section_scaffold.dart';

class NombreScreen extends StatelessWidget {
  const NombreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Usamos el scaffold personalizado pasando el título y el subtítulo de esta sección
    return SectionScaffold(
      title: 'Mi nombre',
      subtitle: 'Presentación personal',
      // Metemos todo dentro de una tarjeta (Card) blanca para que resalte sobre el fondo gris
      child: Card(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20), // Margen interno para que el texto no toque los bordes
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, // Alineamos todo el contenido a la izquierda
            children: [
              // Requisito: Usamos la fuente Poppins de Google Fonts para el nombre completo
              Text(
                'Mohamed El Baghdadi El Belhadji',
                style: GoogleFonts.poppins(
                  fontSize: 23,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF303F82), // Un color azul oscuro que combine con el tema
                ),
              ),
              const SizedBox(height: 12), // Espacio de separación
              const Text('2.º DAM - Programación Móvil'),
              
              const Divider(height: 30), // Línea horizontal divisoria para separar las secciones
              
              const Text(
                'Mi repositorio de GitHub:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              
              // Requisito: Usamos SelectableText en vez de Text por si el profesor quiere copiar la URL desde la app.
              // Le ponemos fuente monospace (tipo consola de comandos) para diferenciarla bien.
              const SelectableText(
                'https://github.com/Ekisten/entrega1_flutter',
                style: TextStyle(
                  fontFamily: 'monospace',
                  color: Color(0xFF5367B8),
                ),
              ),
              const SizedBox(height: 8),
              
              // Pequeño texto aclaratorio al final con un tamaño de letra más reducido
              const Text(
                'Este es mi repositorio de Programación Móvil de 2.º DAM.',
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
