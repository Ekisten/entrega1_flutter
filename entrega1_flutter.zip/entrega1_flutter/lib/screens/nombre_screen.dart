import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/section_scaffold.dart';

class NombreScreen extends StatelessWidget {
  const NombreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Mi nombre',
      subtitle: 'Presentación personal',
      child: Card(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Mohamed El Baghdadi El Belhadji',
                style: GoogleFonts.poppins(
                  fontSize: 23,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF303F82),
                ),
              ),
              const SizedBox(height: 12),
              const Text('2.º DAM - Programación Móvil'),
              const Divider(height: 30),
              const Text(
                'Mi repositorio de GitHub:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const SelectableText(
                'https://github.com/Ekisten/entrega1_flutter',
                style: TextStyle(
                  fontFamily: 'monospace',
                  color: Color(0xFF5367B8),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Este es mi repositorio de Programación Móvil de 2.º DAM.',
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
