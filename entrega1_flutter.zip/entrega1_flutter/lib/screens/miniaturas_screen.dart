import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class MiniaturasScreen extends StatelessWidget {
  const MiniaturasScreen({super.key});

  // Imágenes que se muestran en la lista
  static const fotos = [
    ('Paisaje', 'https://media.istockphoto.com/id/1069539210/es/foto/fant%C3%A1stico-atardecer-oto%C3%B1al-del-lago-hintersee.jpg?s=612x612&w=0&k=20&c=q6F3C0nKio2cKfmMEqw6LFc-mDhKUTT8DXrO0muaMtc='),
    ('Montañas', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiXKJCEra96yRQIa4ySQLiwzD2SZ8endaUeViqqH1GCh6uDncYlNH6Tsk&s=10'),
    ('Atardecer', 'https://img.magnific.com/foto-gratis/al-atardecer-playa-tropical-mar-palmeras-coco_74190-1075.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Miniaturas',
      subtitle: 'Tres fotos colocadas en filas',
      child: Column(
        children: [
          for (final foto in fotos)
            Card(
              color: Colors.white,
              clipBehavior: Clip.antiAlias,
              margin: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Image.network(
                    foto.$2,
                    width: 125,
                    height: 110,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 125,
                        height: 110,
                        color: const Color(0xFFE7EAF8),
                        child: const Icon(Icons.image),
                      );
                    },
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Text(
                      foto.$1,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
