import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class MiniaturasScreen extends StatelessWidget {
  const MiniaturasScreen({super.key});

  // Lista de tuplas estáticas para guardar los datos de las tres fotos (Título, URL de la imagen)
  static const fotos = [
    ('Paisaje', 'https://media.istockphoto.com/id/1069539210/es/foto/fant%C3%A1stico-atardecer-oto%C3%B1al-del-lago-hintersee.jpg?s=612x612&w=0&k=20&c=q6F3C0nKio2cKfmMEqw6LFc-mDhKUTT8DXrO0muaMtc='),
    ('Montañas', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiXKJCEra96yRQIa4ySQLiwzD2SZ8endaUeViqqH1GCh6uDncYlNH6Tsk&s=10'),
    ('Atardecer', 'https://img.magnific.com/foto-gratis/al-atardecer-playa-tropical-mar-palmeras-coco_74190-1075.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Miniaturas',
      subtitle: 'Tres fotos colocadas en filas', // Indicamos la descripción de la sección
      child: Column(
        children: [
          // Usamos un bucle for inline para recorrer las fotos y renderizar una tarjeta por cada una
          for (final foto in fotos)
            Card(
              color: Colors.white,
              // clipBehavior evita que los bordes cuadrados de la imagen se salgan del redondeado de la tarjeta
              clipBehavior: Clip.antiAlias,
              margin: const EdgeInsets.only(bottom: 12), // Separación entre tarjetas hacia abajo
              child: Row(
                children: [
                  // Cargamos la imagen desde internet usando la posición 2 de nuestra tupla ($2)
                  Image.network(
                    foto.$2,
                    width: 125, // Forzamos un tamaño fijo para la miniatura
                    height: 110,
                    fit: BoxFit.cover, // Recorta y centra la imagen para que rellene el espacio sin deformarse
                    // Si falla el internet o la URL da error, mostramos un contenedor gris con un icono por defecto
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 125,
                        height: 110,
                        color: const Color(0xFFE7EAF8),
                        child: const Icon(Icons.image),
                      );
                    },
                  ),
                  const SizedBox(width: 15), // Separación entre la imagen y el texto de la derecha
                  Expanded(
                    // Mostramos el nombre de la foto (posición 1 de la tupla -> $1)
                    child: Text(
                      foto.$1,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
