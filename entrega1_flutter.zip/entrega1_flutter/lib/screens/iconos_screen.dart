import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class IconosScreen extends StatelessWidget {
  const IconosScreen({super.key});

  // Los cinco iconos de la actividad
  static const iconos = [
    (Icons.home, 'Inicio'),
    (Icons.favorite, 'Favoritos'),
    (Icons.music_note, 'Música'),
    (Icons.camera_alt, 'Fotografía'),
    (Icons.star, 'Mis intereses'),
  ];

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Iconos',
      subtitle: 'Cinco iconos organizados en filas',
      child: Column(
        children: [
          for (final item in iconos)
            Card(
              color: Colors.white,
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: Icon(
                  item.$1,
                  color: const Color(0xFF5367B8),
                  size: 30,
                ),
                title: Text(item.$2),
              ),
            ),
        ],
      ),
    );
  }
}
