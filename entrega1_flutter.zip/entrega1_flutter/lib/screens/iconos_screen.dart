import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class IconosScreen extends StatelessWidget {
  const IconosScreen({super.key});

  // Lista estática con los cinco iconos y sus etiquetas correspondientes que nos pide el ejercicio
  static const iconos = [
    (Icons.home, 'Inicio'),
    (Icons.favorite, 'Favoritos'),
    (Icons.music_note, 'Música'),
    (Icons.camera_alt, 'Fotografía'),
    (Icons.star, 'Mis intereses'),
  ];

  @override
  Widget build(BuildContext context) {
    // Usamos nuestra plantilla base indicando la información propia de este apartado
    return SectionScaffold(
      title: 'Iconos',
      subtitle: 'Cinco iconos organizados en filas',
      child: Column(
        children: [
          // Con un bucle for en la colección generamos una tarjeta visual para cada elemento de la lista
          for (final item in iconos)
            Card(
              color: Colors.white,
              margin: const EdgeInsets.only(bottom: 10), // Separación vertical para que no se peguen
              child: ListTile(
                // Requisito: Colocamos el icono a la izquierda usando la posición 1 de la tupla ($1)
                leading: Icon(
                  item.$1,
                  color: const Color(0xFF5367B8), // Mantenemos el color azul/morado corporativo de la app
                  size: 30, // Un tamaño un poco más grande de lo normal para que destaque bien
                ),
                // Colocamos el nombre o descripción al lado del icono usando la posición 2 ($2)
                title: Text(item.$2),
              ),
            ),
        ],
      ),
    );
  }
}
