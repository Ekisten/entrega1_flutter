import 'package:flutter/material.dart';
import '../widgets/app_drawer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // Pantallas que aparecen en la página principal
  static const apartados = [
    ('Mi nombre', 'Nombre y enlace del repositorio', Icons.person_outline, '/nombre'),
    ('Mi foto', 'Imagen y nombre completo', Icons.account_circle_outlined, '/foto'),
    ('Miniaturas', 'Tres fotografías', Icons.photo_library_outlined, '/miniaturas'),
    ('Iconos', 'Cinco iconos en filas', Icons.widgets_outlined, '/iconos'),
    ('Imágenes', 'Cinco imágenes en columna', Icons.image_outlined, '/imagenes'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(title: const Text('Práctica de Flutter')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: const Color(0xFFE7EAF8),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Hola, soy Mohamed',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF303F82),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Esta es mi práctica de Programación Móvil de 2.º DAM.',
                  style: TextStyle(height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Apartados',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          for (final apartado in apartados)
            Card(
              color: Colors.white,
              elevation: 1,
              margin: const EdgeInsets.only(bottom: 9),
              child: ListTile(
                leading: Icon(apartado.$3, color: const Color(0xFF5367B8)),
                title: Text(apartado.$1),
                subtitle: Text(apartado.$2),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.pushNamed(context, apartado.$4);
                },
              ),
            ),
        ],
      ),
    );
  }
}
