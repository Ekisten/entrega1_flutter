import 'package:flutter/material.dart';
import '../widgets/app_drawer.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // Lista con los apartados de la app para pintar los accesos directos en el menú principal
  // Formato de tupla abajo
  static const apartados = [
    ('Mi nombre', 'Nombre y enlace del repositorio', Icons.person_outline, '/nombre'),
    ('Mi foto', 'Imagen y nombre completo', Icons.account_circle_outlined, '/foto'),
    ('Miniaturas', 'Tres fotografías', Icons.photo_library_outlined, '/miniaturas'),
    ('Iconos', 'Cinco iconos en filas', Icons.widgets_outlined, '/iconos'),
    ('Imágenes', 'Cinco imágenes en columna', Icons.image_outlined, '/imagenes'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(), // Anclamos el menú lateral en la pantalla principal
      appBar: AppBar(title: const Text('Práctica de Flutter')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          // Tarjeta superior tipo banner de bienvenida del alumno
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: const Color(0xFFE7EAF8), // Color de fondo suave que contrasta con el tema general
              borderRadius: BorderRadius.circular(18), // Bordes bien redondeados para estilo moderno
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Hola, soy Mohamed',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF303F82),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Esta es mi práctica de Programación Móvil de 2.º DAM.',
                  style: TextStyle(height: 1.4), // Ajustamos el interlineado para que sea más legible
                ),
              ],
            ),
          ),
          const SizedBox(height: 22), // Espaciador intermedio
          
          const Text(
            'Apartados',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          
          // Generamos la lista de tarjetas dinámicamente con un bucle for recorriendo los apartados
          for (final apartado in apartados)
            Card(
              color: Colors.white,
              elevation: 1, // Sombra sutil debajo de cada fila de la lista
              margin: const EdgeInsets.only(bottom: 9),
              child: ListTile(
                leading: Icon(apartado.$3, color: const Color(0xFF5367B8)), // Icono de la tupla ($3)
                title: Text(apartado.$1), // Título principal ($1)
                subtitle: Text(apartado.$2), // Texto aclaratorio inferior ($2)
                trailing: const Icon(Icons.chevron_right), // Icono de flecha a la derecha tipo "botón"
                onTap: () {
                  // Al pulsar, nos redirige a la pantalla destino usando la ruta de la tupla ($4)
                  Navigator.pushNamed(context, apartado.$4);
                },
              ),
            ),
        ],
      ),
    );
  }
}
