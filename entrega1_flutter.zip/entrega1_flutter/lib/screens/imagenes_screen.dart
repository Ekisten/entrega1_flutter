import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class ImagenesScreen extends StatelessWidget {
  const ImagenesScreen({super.key});

  // Lista estática con las 5 imágenes que nos pide el ejercicio del Tema 1
  static const imagenes = [
    ('Costa', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzwQwJyPQJSyRhtjhX81FNjHKg1lxfhQMCXu8gO7Tu-ZGg3apLvgB4eOY-&s=10'),
    ('Naturaleza', 'https://img.magnific.com/foto-gratis/cascada-barco-limpio-china-natural_1417-1356.jpg'),
    ('Ciudad', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUonglHcWF5e6JY1X49zHKzCiMkZy9aWZBo5SvMuJ3og&s=10'),
    ('Desierto', 'https://img.magnific.com/foto-gratis/hermoso-paisaje-dunas-arena-mesquite-flat-death-valley-california_181624-22370.jpg?semt=ais_hybrid&w=740&q=80'),
    ('Lago', 'https://cdn.pixabay.com/photo/2017/05/09/03/46/alberta-2297204_1280.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Imágenes',
      subtitle: 'Cinco imágenes colocadas en una columna',
      child: Column(
        children: [
          // Recorremos la lista de las 5 imágenes para maquetarlas verticalmente
          for (final imagen in imagenes)
            Card(
              color: Colors.white,
              clipBehavior: Clip.antiAlias, // Redondea también la imagen superior de la tarjeta
              margin: const EdgeInsets.only(bottom: 15), // Separación entre bloques de tarjetas
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, // Alineamos el texto inferior a la izquierda
                children: [
                  // Imagen a pantalla completa ocupando todo el ancho disponible del Card
                  Image.network(
                    imagen.$2,
                    width: double.infinity, // Ocupa todo el ancho horizontal
                    height: 190, // Le damos una altura fija generosa para que luzca tipo "post"
                    fit: BoxFit.cover, // Evitamos que las fotos se estiren feo
                    // Control de errores por si alguna imagen del servidor no responde
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 190,
                        color: const Color(0xFFE7EAF8),
                        child: const Center(child: Icon(Icons.image, size: 45)),
                      );
                    },
                  ),
                  // Bloque de texto inferior con padding para que no quede pegado a los bordes de la tarjeta
                  Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(
                      imagen.$1, // Nombre descriptivo de la imagen
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
