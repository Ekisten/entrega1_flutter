import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class FotoScreen extends StatelessWidget {
  const FotoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Reutilizamos el scaffold común de las pantallas pasándole el título y subtítulo de la sección
    return SectionScaffold(
      title: 'Mi foto',
      subtitle: 'Una imagen que me representa',
      child: Column(
        children: [
          // ClipRRect nos sirve para redondear los bordes de la imagen de forma limpia
          ClipRRect(
            borderRadius: BorderRadius.circular(16), // Radio de curvatura de las esquinas
            child: Image.network(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQepai097LmZ2q3b0aikV9X-Z6bkV1MOmuPYQiwt5a2rcwN09v7uuY8JdNV&s=10',
              width: double.infinity, // Hacemos que ocupe todo el ancho de la tarjeta disponible
              height: 320,            // Altura fija para que quede bien encuadrada la foto
              fit: BoxFit.cover,      // Recorta la imagen proporcionalmente para rellenar el espacio sin deformarla
              // Método de control por si falla la conexión y la URL remota no carga en el dispositivo
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 320,
                  color: const Color(0xFFE7EAF8), // Color de fondo plano que encaja con el tema de la app
                  child: const Icon(Icons.person, size: 100), // Colocamos un icono genérico de usuario grande
                );
              },
            ),
          ),
          const SizedBox(height: 18), // Separación vertical entre la foto y el texto inferior
          
          // Nombre completo justo debajo de la foto representativa
          const Text(
            'Mohamed El Baghdadi El Belhadji',
            textAlign: TextAlign.center, // Centramos el texto por si salta en varias líneas
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold, // Ponemos el texto en negrita para resaltar
              color: Color(0xFF303F82),    // Color azul oscuro corporativo
            ),
          ),
        ],
      ),
    );
  }
}
