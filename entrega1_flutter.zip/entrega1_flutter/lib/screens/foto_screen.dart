import 'package:flutter/material.dart';
import '../widgets/section_scaffold.dart';

class FotoScreen extends StatelessWidget {
  const FotoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SectionScaffold(
      title: 'Mi foto',
      subtitle: 'Una imagen que me representa',
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.network(
              'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQepai097LmZ2q3b0aikV9X-Z6bkV1MOmuPYQiwt5a2rcwN09v7uuY8JdNV&s=10',
              width: double.infinity,
              height: 320,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 320,
                  color: const Color(0xFFE7EAF8),
                  child: const Icon(Icons.person, size: 100),
                );
              },
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Mohamed El Baghdadi El Belhadji',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF303F82),
            ),
          ),
        ],
      ),
    );
  }
}
