import 'package:flutter/material.dart';
import 'app_drawer.dart';

// Creamos esta estructura base para no tener que repetir el Scaffold, el AppBar y el Drawer en cada uno de los archivos de las pantallas.
class SectionScaffold extends StatelessWidget {
  final String title;    // El título que se verá arriba en la barra de la app
  final String subtitle; // Un pequeño texto descriptivo para el inicio de la pantalla
  final Widget child;    // El contenido específico que meteremos dentro de cada sección

  const SectionScaffold({
    super.key,
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Le metemos el menú lateral personalizado que nos pide la práctica
      drawer: const AppDrawer(),
      appBar: AppBar(title: Text(title)),
      // Usamos SafeArea para que el contenido no se pise con la barra de notificaciones o el notch
      body: SafeArea(
        // SingleChildScrollView sirve para que se pueda hacer scroll y no nos salte el error de píxeles (overflow)
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Texto para el subtítulo con un color grisáceo suave
              Text(
                subtitle,
                style: const TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 18), // Separación entre el subtítulo y el bloque de contenido
              child, // Aquí se dibuja el layout que le pasemos desde cada pantalla
            ],
          ),
        ),
      ),
    );
  }
}
