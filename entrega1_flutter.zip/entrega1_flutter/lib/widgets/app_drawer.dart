import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  // Opciones del menú
  static const opciones = [
    ('Inicio', '/', Icons.home_outlined),
    ('Mi nombre', '/nombre', Icons.person_outline),
    ('Mi foto', '/foto', Icons.account_circle_outlined),
    ('Miniaturas', '/miniaturas', Icons.photo_library_outlined),
    ('Iconos', '/iconos', Icons.widgets_outlined),
    ('Imágenes', '/imagenes', Icons.image_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 55, 20, 25),
            color: const Color(0xFF5367B8),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 35, color: Color(0xFF5367B8)),
                ),
                SizedBox(height: 15),
                Text(
                  'Mohamed El Baghdadi\nEl Belhadji',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  '2.º DAM · Programación Móvil',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Elementos para cambiar de pantalla
          Expanded(
            child: ListView(
              children: [
                for (final opcion in opciones)
                  ListTile(
                    leading: Icon(opcion.$3),
                    title: Text(opcion.$1),
                    onTap: () {
                      Navigator.pop(context);
                      if (ModalRoute.of(context)?.settings.name != opcion.$2) {
                        Navigator.pushReplacementNamed(context, opcion.$2);
                      }
                    },
                  ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Actividad del Tema 1',
              style: TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
