import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'screens/nombre_screen.dart';
import 'screens/foto_screen.dart';
import 'screens/miniaturas_screen.dart';
import 'screens/iconos_screen.dart';
import 'screens/imagenes_screen.dart';

void main() {
  runApp(const MiApp());
}

class MiApp extends StatelessWidget {
  const MiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Práctica Flutter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5367B8),
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F7FB),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/nombre': (context) => const NombreScreen(),
        '/foto': (context) => const FotoScreen(),
        '/miniaturas': (context) => const MiniaturasScreen(),
        '/iconos': (context) => const IconosScreen(),
        '/imagenes': (context) => const ImagenesScreen(),
      },
    );
  }
}
