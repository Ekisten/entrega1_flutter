import 'package:flutter/material.dart';

// Importamos todas las pantallas de la app para poder usarlas en el sistema de rutas
import 'screens/home_screen.dart';
import 'screens/nombre_screen.dart';
import 'screens/foto_screen.dart';
import 'screens/miniaturas_screen.dart';
import 'screens/iconos_screen.dart';
import 'screens/imagenes_screen.dart';

void main() {
  // Punto de entrada de la aplicación, arranca el widget principal
  runApp(const MiApp());
}

class MiApp extends StatelessWidget {
  const MiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Práctica Flutter',
      // Quitamos la etiqueta flotante de "Debug" que sale arriba a la derecha para que quede más limpio
      debugShowCheckedModeBanner: false,
      
      // Configuramos el diseño visual global de toda la aplicación
      theme: ThemeData(
        useMaterial3: true, // Activamos Material 3 para tener los componentes más modernos
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5367B8), // Color base (morado/azul) para generar la paleta de colores
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F7FB), // Un tono gris claro de fondo para que no canse la vista
      ),

      // Definimos cuál va a ser la pantalla de inicio nada más abrir la app
      initialRoute: '/',

      // Mapa de rutas de la app. Así gestionamos el cambio de pantallas de forma limpia 
      // usando nombres clave en lugar de repetir código en cada botón del menú
      routes: {
        '/': (context) => const HomeScreen(),                  // Pantalla principal de bienvenida
        '/nombre': (context) => const NombreScreen(),          // Datos personales y enlace de GitHub con Google Fonts
        '/foto': (context) => const FotoScreen(),              // Avatar/Foto de perfil con el nombre abajo
        '/miniaturas': (context) => const MiniaturasScreen(),  // Estructura de 3 fotos dispuestas en columnas
        '/iconos': (context) => const IconosScreen(),          // Fila con los 5 iconos de Material
        '/imagenes': (context) => const ImagenesScreen(),      // Columna completa con las 5 imágenes del ejercicio
      },
    );
  }
}
